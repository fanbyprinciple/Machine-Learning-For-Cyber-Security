from setuptools import setup

setup(
    name='lie_to_me',
    packages=['lie_to_me'],
    include_package_data=True,
    zip_safe=False,
    install_requires=[
        'flask',
    ],
)